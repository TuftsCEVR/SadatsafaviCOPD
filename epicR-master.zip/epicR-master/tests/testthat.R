library(testthat)
library(epicR)

test_check("epicR")
